const fs = require('fs');
const path = require('path');
const assert = require('assert');
const csv = require('csv-parser');

const mockDB = require('./mockdb.json');
const results = [];

fs.createReadStream(path.join(__dirname, 'testdata.csv'))
  .pipe(csv())
  .on('data', (data) => results.push(data))
  .on('end', () => {
    results.forEach(({ username, password, expected }) => {
      const found = mockDB.find(
        (record) => record.username === username && record.password === password
      );
      const actual = !!found;
      console.log(`Testing ${username}: expected=${expected}, actual=${actual}`);
      assert.strictEqual(actual, expected === 'true');
    });
    console.log('All tests passed.');
  });
