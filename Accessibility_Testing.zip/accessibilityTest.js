const puppeteer = require('puppeteer');
const { AxePuppeteer } = require('@axe-core/puppeteer');

(async () => {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  await page.goto('https://example.com');

  const results = await new AxePuppeteer(page).analyze();
  console.log('Accessibility Violations:', results.violations);

  await browser.close();
})();
