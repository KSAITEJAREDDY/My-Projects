# Accessibility Testing with Axe & Puppeteer

This project demonstrates automated accessibility testing using the Axe-core engine integrated with Puppeteer.

## Scenario
We analyze the accessibility of https://example.com and report any violations.

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Run the accessibility test:
   ```bash
   npm test
   ```

## Notes
- Puppeteer automates Chromium and navigates to the URL.
- Axe runs an accessibility audit and prints violations to the console.

> Ideal for catching issues related to WCAG compliance automatically.
