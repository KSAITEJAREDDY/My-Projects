# JMeter Performance Test Plan

This JMeter test simulates 5 users making GET requests to `/posts` on `jsonplaceholder.typicode.com`.

## Configuration
- 5 Threads (Users)
- 10 Iterations per user
- 10-second ramp-up time

## How to Use
1. Open JMeter GUI
2. File > Open > `performance_test_plan.jmx`
3. Run the test or export to CLI:
   ```bash
   jmeter -n -t performance_test_plan.jmx -l results.jtl
   ```

> You can install JMeter from https://jmeter.apache.org/
