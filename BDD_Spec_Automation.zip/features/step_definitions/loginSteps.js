const { Given, When, Then, setWorldConstructor } = require('@cucumber/cucumber');
const assert = require('assert');

class CustomWorld {
  constructor() {
    this.user = {};
    this.authenticated = false;
  }
}

setWorldConstructor(CustomWorld);

Given('a registered user with username {string} and password {string}', function (username, password) {
  this.user.username = username;
  this.user.password = password;
});

When('the user logs in with valid credentials', function () {
  if (this.user.username === 'demo' && this.user.password === 'demo') {
    this.authenticated = true;
  }
});

Then('they should be redirected to the dashboard', function () {
  assert.strictEqual(this.authenticated, true, 'User should be authenticated');
});
