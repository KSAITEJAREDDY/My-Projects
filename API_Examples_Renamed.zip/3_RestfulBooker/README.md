# Restful Booker API Example

API automation testing framework using RestAssured against the Restful Booker API.

## Features
- Booking CRUD tests
- Token-based authentication
- JSON schema validation and deserialization

## Usage
```bash
mvn test
```
