const axios = require('axios');

(async () => {
  const booking = {
    firstname: 'Jim',
    lastname: 'Brown',
    totalprice: 111,
    depositpaid: true,
    bookingdates: {
      checkin: '2025-01-01',
      checkout: '2025-01-10'
    },
    additionalneeds: 'Breakfast'
  };

  const response = await axios.post('https://restful-booker.herokuapp.com/booking', booking);
  console.log('Booking Created:', response.data);
})();
