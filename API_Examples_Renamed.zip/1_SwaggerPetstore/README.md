# Swagger Petstore Example

This project demonstrates how to mock and test the Swagger Petstore API using OpenAPI-generated clients and mock servers.

## Features
- Mock server via Prism
- Deserialization using OpenAPI-generated models
- Approval testing with stored JSON responses

## Usage
```bash
npm install -g @stoplight/prism-cli
prism mock https://petstore.swagger.io/v2/swagger.json
```
