const axios = require('axios');

(async () => {
  const response = await axios.get('https://petstore.swagger.io/v2/pet/findByStatus?status=available');
  console.log('Available Pets:', response.data.slice(0, 2));
})();
