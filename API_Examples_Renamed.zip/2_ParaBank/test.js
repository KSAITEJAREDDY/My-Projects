const axios = require('axios');

(async () => {
  try {
    const response = await axios.get('https://parabank.parasoft.com/parabank/services/bank/customers/12212/');
    console.log('Customer Details:', response.data);
  } catch (err) {
    console.error('Failed to fetch customer data', err);
  }
})();
