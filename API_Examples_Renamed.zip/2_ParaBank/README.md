# ParaBank API Example

This project connects to the ParaBank demo banking API and demonstrates how to write automated tests with RestAssured.

## Features
- Account creation and fund transfer scenarios
- Mocking failed transactions using MockServer

## Usage
Run the ParaBank server locally:
```bash
git clone https://github.com/parasoft/parabank.git
cd parabank
mvn clean install
```
