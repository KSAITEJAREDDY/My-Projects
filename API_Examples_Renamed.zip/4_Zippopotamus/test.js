const axios = require('axios');

(async () => {
  const response = await axios.get('https://api.zippopotam.us/us/90210');
  console.log('Postal Info:', response.data);
})();
