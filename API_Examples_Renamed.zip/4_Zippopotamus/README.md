# Zippopotam.us API Example

Demonstrates how to test postal lookup APIs with static data.

## Features
- Mock server using static JSON
- Deserialization into postal data models
- Approval testing of lookup responses

## Usage
Serve the static JSON locally or mock it using tools like Mockoon or Prism.
